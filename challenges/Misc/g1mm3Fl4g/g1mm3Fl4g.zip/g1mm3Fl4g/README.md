# G1mm3Fl4g
---

Once upon a time, a program was created to alter any file. However, the program was accidentally
deleted which means that the flag is effectively lost as well.

PLEASE HELP ME TO RECOVER THE FLAG FROM THIS FILE! THANKS

### Hints about the program gimmeflag
---

1) This was developed and compiled for 64 bit machines
2) Each and every of the bytes were altered with a single operation
3) Format : Executable and Linkable Format
4) Contains the flag when run

---
