#M4nyCh3cK5
---

This is a program that checks intensely on the correctness of the flag.
It also confirms that the flag that you get is correct. Can you get the flag?

---
