Please get the flag from this file :)
